﻿Public Class ImageLoaderFomr
    Private Sub ImageLoaderFomr_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Me.CenterToScreen()
    End Sub

    Public Sub LoadToImageBox(BitMap As Bitmap)
    End Sub

End Class